﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.jugador1 = new System.Windows.Forms.Label();
            this.nombre1 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.jugador2 = new System.Windows.Forms.Label();
            this.nombre2 = new System.Windows.Forms.TextBox();
            this.veces = new System.Windows.Forms.RadioButton();
            this.tiempo = new System.Windows.Forms.RadioButton();
            this.puntotal = new System.Windows.Forms.RadioButton();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // jugador1
            // 
            this.jugador1.AutoSize = true;
            this.jugador1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jugador1.Location = new System.Drawing.Point(25, 60);
            this.jugador1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.jugador1.Name = "jugador1";
            this.jugador1.Size = new System.Drawing.Size(134, 31);
            this.jugador1.TabIndex = 1;
            this.jugador1.Text = "Jugador 1";
            // 
            // nombre1
            // 
            this.nombre1.Location = new System.Drawing.Point(165, 69);
            this.nombre1.Margin = new System.Windows.Forms.Padding(4);
            this.nombre1.Name = "nombre1";
            this.nombre1.Size = new System.Drawing.Size(207, 22);
            this.nombre1.TabIndex = 3;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(174, 257);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(100, 28);
            this.button2.TabIndex = 5;
            this.button2.Text = "Enviar";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.jugador2);
            this.groupBox1.Controls.Add(this.nombre2);
            this.groupBox1.Controls.Add(this.veces);
            this.groupBox1.Controls.Add(this.tiempo);
            this.groupBox1.Controls.Add(this.puntotal);
            this.groupBox1.Controls.Add(this.jugador1);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.nombre1);
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(484, 300);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Peticion";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(28, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(404, 34);
            this.label1.TabIndex = 12;
            this.label1.Text = "Si solo quieres datos sobre un jugador, escribe en \"jugador 1\".\r\n Para la tercera" +
    " consulta escribe los dos jugadores.";
            // 
            // jugador2
            // 
            this.jugador2.AutoSize = true;
            this.jugador2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jugador2.Location = new System.Drawing.Point(28, 91);
            this.jugador2.Name = "jugador2";
            this.jugador2.Size = new System.Drawing.Size(120, 29);
            this.jugador2.TabIndex = 11;
            this.jugador2.Text = "Jugador 2";
            // 
            // nombre2
            // 
            this.nombre2.Location = new System.Drawing.Point(165, 98);
            this.nombre2.Name = "nombre2";
            this.nombre2.Size = new System.Drawing.Size(207, 22);
            this.nombre2.TabIndex = 10;
            // 
            // veces
            // 
            this.veces.AutoSize = true;
            this.veces.Location = new System.Drawing.Point(155, 201);
            this.veces.Name = "veces";
            this.veces.Size = new System.Drawing.Size(196, 21);
            this.veces.TabIndex = 9;
            this.veces.TabStop = true;
            this.veces.Text = "Veces que J1 derrotó a J2";
            this.veces.UseVisualStyleBackColor = true;
            // 
            // tiempo
            // 
            this.tiempo.AutoSize = true;
            this.tiempo.Location = new System.Drawing.Point(155, 173);
            this.tiempo.Margin = new System.Windows.Forms.Padding(4);
            this.tiempo.Name = "tiempo";
            this.tiempo.Size = new System.Drawing.Size(287, 21);
            this.tiempo.TabIndex = 7;
            this.tiempo.TabStop = true;
            this.tiempo.Text = "Dime el tiempo total jugado del jugador 1";
            this.tiempo.UseVisualStyleBackColor = true;
            // 
            // puntotal
            // 
            this.puntotal.AutoSize = true;
            this.puntotal.Location = new System.Drawing.Point(155, 144);
            this.puntotal.Margin = new System.Windows.Forms.Padding(4);
            this.puntotal.Name = "puntotal";
            this.puntotal.Size = new System.Drawing.Size(267, 21);
            this.puntotal.TabIndex = 8;
            this.puntotal.TabStop = true;
            this.puntotal.Text = "Dime los puntos totales del Jugador 1";
            this.puntotal.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(484, 299);
            this.Controls.Add(this.groupBox1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label jugador1;
        private System.Windows.Forms.TextBox nombre1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton tiempo;
        private System.Windows.Forms.RadioButton puntotal;
        private System.Windows.Forms.RadioButton veces;
        private System.Windows.Forms.Label jugador2;
        private System.Windows.Forms.TextBox nombre2;
        private System.Windows.Forms.Label label1;
    }
}

